import requests

url = 'https://juhaadrmihxlp77nkq712yazcldwshs3fod3ulmovfu2edibsot4csyd.onion/'
user, password = '', ''
resp = requests.get(url, auth=(user, password))

print(resp) # i need to save this somewhere